import xml.etree.ElementTree as ET

class MAMESoftwareList:
    def __init__(self, xml_path):
        self.xml_path = xml_path
        self.mapping = {}
        self._load_xml()

    def _load_xml(self):
        try:
            tree = ET.parse(self.xml_path)
            root = tree.getroot()

            # MAME software list format:
            # <software name="shortname">
            #   <description>Full Game Name</description>
            # </software>
            for software in root.findall("software"):
                short_name = software.get("name")
                desc_node = software.find("description")
                if short_name and desc_node is not None:
                    self.mapping[short_name.lower()] = desc_node.text
        except Exception as e:
            print(f"Error parsing {self.xml_path}: {e}")

    def get_name(self, short_name, fallback=None):
        """Return full descriptive name if found, else fallback"""
        return self.mapping.get(short_name.lower(), fallback or short_name)
