import os
import tkinter as tk
from tkinter import filedialog, messagebox, font
from mame_softlist import MAMESoftwareList
import json

SETTINGS_FILE = "settings.json"

class GameListGenerator(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("ESDE Gamelist Generator")
        self.geometry("400x380")
        self.minsize(350, 380)
        self.configure(bg="#121212")

        self.bg_color = "#121212"
        self.text_color = "#00FF00"
        self.entry_bg = "#001100"
        self.button_bg = "#003300"
        self.button_active_bg = "#005500"
        self.highlight_color = "#00FF00"

        self.folder_path = tk.StringVar()
        self.output_folder_path = tk.StringVar()
        self.extensions = tk.StringVar(value=".nes")
        self.recursive = tk.BooleanVar(value=False)
        self.use_mame_softlist = tk.BooleanVar(value=False)
        self.mame_softlist_path = tk.StringVar()

        self.create_widgets()
        self.configure_grid()
        self.load_settings()

    def create_widgets(self):
        default_font = font.nametofont("TkDefaultFont")
        default_font.configure(size=10, family="Consolas")

        label_opts = {"bg": self.bg_color, "fg": self.text_color, "anchor": "w", "font": default_font}
        entry_opts = {"bg": self.entry_bg, "fg": self.text_color, "insertbackground": self.text_color,
                      "font": default_font, "relief": "flat", "highlightthickness": 1,
                      "highlightbackground": self.highlight_color, "highlightcolor": self.highlight_color}
        button_opts = {"bg": self.button_bg, "fg": self.text_color, "activebackground": self.button_active_bg,
                       "activeforeground": self.text_color, "font": default_font, "relief": "flat",
                       "bd": 0, "cursor": "crosshair"}
        checkbox_opts = {"bg": self.bg_color, "fg": self.text_color, "font": default_font,
                         "activebackground": self.bg_color, "activeforeground": self.text_color,
                         "selectcolor": self.bg_color, "anchor": "w"}

        self.lbl_dir = tk.Label(self, text="ROM Directory:", **label_opts)
        self.ent_dir = tk.Entry(self, textvariable=self.folder_path, **entry_opts)
        self.btn_browse = tk.Button(self, text="Browse...", command=self.browse_folder, **button_opts)

        self.lbl_output_dir = tk.Label(self, text="Base Gamelist Folder (e.g. ES-DE/gamelists):", **label_opts)
        self.ent_output_dir = tk.Entry(self, textvariable=self.output_folder_path, **entry_opts)
        self.btn_output_browse = tk.Button(self, text="Browse...", command=self.browse_output_folder, **button_opts)

        self.lbl_ext = tk.Label(self, text="File Extensions (e.g. .nes,.sfc,.zip):", **label_opts)
        self.ent_ext = tk.Entry(self, textvariable=self.extensions, width=20, **entry_opts)

        self.chk_recursive = tk.Checkbutton(self, text="Scan subdirectories recursively", variable=self.recursive, **checkbox_opts)

        self.chk_mame_softlist = tk.Checkbutton(self, text="Use MAME Software List for names",
                                               variable=self.use_mame_softlist, command=self.toggle_softlist, **checkbox_opts)
        self.lbl_softlist = tk.Label(self, text="MAME Software List XML:", **label_opts)
        self.ent_softlist = tk.Entry(self, textvariable=self.mame_softlist_path, **entry_opts, state="disabled")
        self.btn_softlist = tk.Button(self, text="Browse...", command=self.browse_softlist, **button_opts, state="disabled")

        self.btn_generate = tk.Button(self, text="Generate gamelist.xml", command=self.generate_gamelist, **button_opts)
        self.btn_clear = tk.Button(self, text="Clear", command=self.clear_fields, **button_opts)

        self.lbl_dir.grid(row=0, column=0, sticky="w", padx=15, pady=(15, 2), columnspan=3)
        self.ent_dir.grid(row=1, column=0, columnspan=2, sticky="we", padx=(15, 2), pady=2)
        self.btn_browse.grid(row=1, column=2, sticky="e", padx=(2, 15), pady=2)
        self.lbl_output_dir.grid(row=2, column=0, sticky="w", padx=15, pady=(10, 2), columnspan=3)
        self.ent_output_dir.grid(row=3, column=0, columnspan=2, sticky="we", padx=(15, 2), pady=2)
        self.btn_output_browse.grid(row=3, column=2, sticky="e", padx=(2, 15), pady=2)
        self.lbl_ext.grid(row=4, column=0, sticky="w", padx=15, pady=(10, 2), columnspan=3)
        self.ent_ext.grid(row=5, column=0, sticky="we", padx=15, pady=2, columnspan=3)
        self.chk_recursive.grid(row=6, column=0, sticky="w", padx=15, pady=(5, 10), columnspan=3)
        self.chk_mame_softlist.grid(row=7, column=0, sticky="w", padx=15, pady=(5, 2), columnspan=3)
        self.lbl_softlist.grid(row=8, column=0, sticky="w", padx=15, pady=(2, 2), columnspan=3)
        self.ent_softlist.grid(row=9, column=0, columnspan=2, sticky="we", padx=(15, 2), pady=2)
        self.btn_softlist.grid(row=9, column=2, sticky="e", padx=(2, 15), pady=2)
        self.btn_generate.grid(row=10, column=0, sticky="we", padx=15, pady=(10, 10), columnspan=2)
        self.btn_clear.grid(row=10, column=2, sticky="we", padx=15, pady=(10, 10))

    def configure_grid(self):
        self.grid_columnconfigure(0, weight=1)
        self.grid_columnconfigure(1, weight=1)
        self.grid_columnconfigure(2, weight=0)
        self.grid_rowconfigure(11, weight=1)

    def toggle_softlist(self):
        state = "normal" if self.use_mame_softlist.get() else "disabled"
        self.ent_softlist.configure(state=state)
        self.btn_softlist.configure(state=state)

    def browse_folder(self):
        selected_folder = filedialog.askdirectory()
        if selected_folder:
            self.folder_path.set(selected_folder)

    def browse_output_folder(self):
        selected_folder = filedialog.askdirectory()
        if selected_folder:
            self.output_folder_path.set(selected_folder)

    def browse_softlist(self):
        filetypes = [("XML files", "*.xml"), ("All files", "*.*")]
        selected_file = filedialog.askopenfilename(filetypes=filetypes)
        if selected_file:
            self.mame_softlist_path.set(selected_file)

    def clear_fields(self):
        self.folder_path.set("")
        self.output_folder_path.set("")
        self.extensions.set(".nes")
        self.recursive.set(False)
        self.use_mame_softlist.set(False)
        self.mame_softlist_path.set("")
        self.toggle_softlist()

    def load_settings(self):
        if os.path.isfile(SETTINGS_FILE):
            try:
                with open(SETTINGS_FILE, "r", encoding="utf-8") as f:
                    settings = json.load(f)
                    self.folder_path.set(settings.get("rom_dir", ""))
                    self.output_folder_path.set(settings.get("output_dir", ""))
                    self.extensions.set(settings.get("extensions", ".nes"))
                    self.recursive.set(settings.get("recursive", False))
                    self.use_mame_softlist.set(settings.get("use_mame_softlist", False))
                    self.mame_softlist_path.set(settings.get("mame_softlist_path", ""))
                    self.toggle_softlist()
            except Exception as e:
                print(f"Error loading settings: {e}")

    def save_settings(self):
        settings = {"rom_dir": self.folder_path.get(), "output_dir": self.output_folder_path.get(),
                    "extensions": self.extensions.get(), "recursive": self.recursive.get(),
                    "use_mame_softlist": self.use_mame_softlist.get(),
                    "mame_softlist_path": self.mame_softlist_path.get()}
        try:
            with open(SETTINGS_FILE, "w", encoding="utf-8") as f:
                json.dump(settings, f, indent=4)
        except Exception as e:
            print(f"Error saving settings: {e}")

    # The generate_gamelist function would be same as previous version, call save_settings at end

if __name__ == "__main__":
    app = GameListGenerator()
    app.mainloop()
